import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Bookings } from 'src/app/model/bookings.model';
import { Machine } from 'src/app/model/machine.model';
import { Reservation } from 'src/app/model/reservation.model';
import { RestDataSource } from 'src/app/model/rest.datasource';
import { Shop } from 'src/app/model/Shop.Model';
import { User } from 'src/app/model/user.model';
import { SharedataService } from 'src/app/sharedata.service';
import Swal from 'sweetalert2';
// import { MdInputModule } from '@angular/material';


@Component({
  selector: 'app-bookingwindow',
  templateUrl: './bookingwindow.component.html',
  styleUrls: ['./bookingwindow.component.css']
})
export class BookingwindowComponent implements OnInit{

  public shop = new Shop;
  public toggle?:boolean;
  public reservations:Reservation[]=[];
  public id:any;
  public shopDetails= new Shop;
  public booking=new Bookings(new Date(),new Date());
  selectedvalue:any
  public bookingList:any[]=[];
  public machineList:any
  public errorMessage:string=''
  public allMachinesId:number[]=[]
  public machinesOccupiedId:number[]=[]
  public availableMachineId:number[]=[]
  public assignedMachine:any=null
  public user=new User()
  public startTime=new Date()
  public endTime=new Date()
  public dateNow = "";
 public date = new Date();
public finalMonth:any;
public finalDay: any;
public finalMinute:any;
public finalHour:any;
public month = this.date.getUTCMonth()+1
public day = this.date.getUTCDate();
 public minute = this.date.getMinutes()
 public hour = this.date.getHours()
 public boolArray?:boolean
 machineName:string=''
 machinedetails=new Machine('')

  
  public userPhoneNo : string | null = sessionStorage.getItem("userPhoneNumber");


  constructor(private router:Router,private sharedata:SharedataService,private datasource:RestDataSource,private route: ActivatedRoute){
    
    
  }
 
  
  
  ngOnInit(): void {
    

    if(this.month<10){
      this.finalMonth = "0"+this.month
  }
  else{
    this.finalMonth = this.month
  }
  if(this.hour<10){
    this.finalHour = "0"+this.hour
}
else{
  this.finalHour = this.hour
}


  if(this.day<10){
    this.finalDay = "0"+this.day
}
else{
  this.finalDay = this.day
}

if(this.minute<10){
  this.finalMinute = "0"+this.minute
}
else{
this.finalMinute = this.minute
}

this.dateNow  = this.date.getUTCFullYear()+"-"+this.finalMonth+"-"+
this.finalDay+"T"+this.finalHour+":"+this.finalMinute
    console.log(this.dateNow)
    this.datasource.GetUserInfo(this.userPhoneNo).subscribe(data=>{
      this.user = data;

      this.booking.userId=this.user.userId;
    })
    console.log(this.userPhoneNo, "user");
    

    

    
    this.id=this.route.snapshot.paramMap.get('id');
    this.id=parseInt(this.id);

    //this.booking.userId=this.user.userId;
    
    
    this.booking.shopId=this.id
    

    console.log(this.id);
    

    
    this.sharedata.currentToggle.subscribe(t=>{
      this.toggle= t;
      console.log(this.toggle)
    })
    this.datasource.GetAllReservation().subscribe(data=>{
      this.reservations=data;
      //console.log(this.reservations)
    })

    this.datasource.GetShopByShopId(this.id).subscribe(data=>{
      this.shopDetails=data
    })
    this.datasource.GetMachinesByShopId(this.id).subscribe(data=>{
      this.machineList=data;
      
     
     for(let i=0;i<this.machineList.length;i++){
      if(this.machineList[i].workingStatus==true){this.allMachinesId.push(this.machineList[i].machineId);}
      
     }
     console.log(this.machineList)
      //console.log(this.machineList)
      //console.log(this.machineList.length); 
      //console.log(this.allMachinesId)
    })



    

    

    
  }
  CheckBooking(bookingStartTime:any){


    //this.datasource.
  console.log(bookingStartTime)
  console.log(this.shopDetails.shopStartTime)



  if(this.shopDetails.shopStartTime!=undefined && this.shopDetails.shopEndTime!=undefined){

    console.log('hwd');
    let FormattedStartTime=new Date(this.shopDetails.shopStartTime);
    let FormattedEndTime=new Date(this.shopDetails.shopEndTime)
    let FormattedBookingStartTime=new Date(bookingStartTime)
   
    
    if(FormattedStartTime.getHours()==FormattedBookingStartTime.getHours()&&FormattedEndTime.getHours()==FormattedBookingStartTime.getHours()){
      if(FormattedStartTime.getMinutes()<=FormattedBookingStartTime.getMinutes()&&FormattedEndTime.getMinutes()>FormattedBookingStartTime.getMinutes()){
       
       this.boolArray=true;
      }
      else{
        
        this.boolArray=false;
      }
    }
    else if(FormattedStartTime.getHours()==FormattedBookingStartTime.getHours()&&FormattedEndTime.getHours()!=FormattedBookingStartTime.getHours()){
      if(FormattedStartTime.getMinutes()<=FormattedBookingStartTime.getMinutes()){
        this.boolArray=true;
      }
      else{
        this.boolArray=false;
      }
    }
    else if(FormattedStartTime.getHours()!=FormattedBookingStartTime.getHours()&&FormattedEndTime.getHours()==FormattedBookingStartTime.getHours()){
      if(FormattedEndTime.getMinutes()>FormattedBookingStartTime.getMinutes()){
        this.boolArray=true;
      }
      else{
        this.boolArray=false;
      }
    }
    else if(FormattedStartTime.getHours()<FormattedBookingStartTime.getHours()&&FormattedEndTime.getHours()>FormattedBookingStartTime.getHours()){
      this.boolArray=true;
    }
    else{
      this.boolArray=false;
    }
    console.log(this.boolArray)
  }

    
    


    this.datasource.GetBookingsByShopId(this.id,this.booking.bookingStartTime).subscribe(data=>{
      this.bookingList=data;

      
      this.startTime=new Date(this.booking.bookingStartTime)
      //this.endTime=new Date(this.endTime.setHours(this.startTime.getHours()+1))
      this.endTime.setTime(this.startTime.getTime()+3600000*6.5)
      console.log(this.endTime)
      //this.booking.bookingEndTime= new Date(this.endTime.getFullYear(),this.endTime.getMonth(),this.endTime.getDay(),this.endTime.getHours(),this.endTime.getMinutes(),this.endTime.getSeconds(),this.endTime.getMilliseconds())
      this.booking.bookingEndTime= this.endTime
      console.log(this.startTime)
      console.log(this.bookingList)
      console.log(this.booking.bookingEndTime,"uheiuhwiq");
      
      
       //console.log(this.machinesOccupiedId)
      //  console.log(this.availableMachineId)
      

    });
    
    
    
  }

  
  
  BookSlot(form:NgForm){
    this.booking.bookingDateTime=new Date()
    //console.log(reservation.reservationId);
    console.log(this.booking.reservationId);


    // Swal.fire({

    //  title:'Are you sure?',
      
    //    text:'you will not be able to recover deleted record',
      
    //    icon:'warning',
      
    //    showCancelButton:true,
      
    //    confirmButtonText:'Yes,delete it!',
      
    //    cancelButtonText:'No,keep it'
      
    //   }).then((result)=>{
      
    //    if(result.value){
      
      
      
      
    //     this.datasource.GetBookingsByShopId(this.id,this.booking.bookingStartTime).subscribe(data=>{
    //       this.bookingList=data;
        
    
    //     this.availableMachineId=[]
        
    //     this.machinesOccupiedId=[]
    
    
    //     for(let i=0;i<this.bookingList.length;i++){
    //       this.machinesOccupiedId.push(this.bookingList[i].machineId);
    //      }
        
    //      console.log(this.allMachinesId)
    //      this.availableMachineId=this.allMachinesId.filter(item =>this.machinesOccupiedId.indexOf(item) < 0);
    //      console.log(this.machinesOccupiedId)
    
        
        
    //     console.log(this.availableMachineId)
    //     console.log(Math.floor(Math.random() * 10));
    
    //     this.assignedMachine=this.availableMachineId[Math.floor(Math.random() * this.availableMachineId.length)]
    //     console.log(this.assignedMachine,"assigned")
    //     this.booking.machineId=this.assignedMachine
    
        
        
        
        
    //     this.datasource.GetReservationById(this.booking.reservationId).subscribe(data=>{
    //       this.booking.bill=data.charges;
    //       console.log(data.charges)
    
    //     })
        
        
    
    //     this.booking.pin=Math.floor(Math.random() * 999999)
    
    //     console.log(this.booking);
        
    //     if(this.allMachinesId.length>this.bookingList.length){
    //       if(form.valid){
    //         console.log(this.booking);
    //         this.datasource.GetMachineByMachineId(this.booking.machineId).subscribe(data=>{
    //           console.log(this.booking.machineId)
    //           this.machinedetails=data;
    //           console.log(this.machinedetails)
    //           this.machineName=this.machinedetails.machineName
    //           console.log(this.machineName);
              
    //           this.datasource.AddSlotBooking(this.booking,this.machineName).subscribe(Response=>{
    //             console.log("booking done");
    //             this.errorMessage="Slot Booked"
    //             console.log(this.booking)
        
                
    //           })
    //         })
            
    //       }
            
    //     }
    //     else{
    //       this.errorMessage="This slot is occupied"
    //     }
        
    //   })
      
    //    Swal.fire(
      
    //    'Deleted!',
      
    //    'Your record has been deleted.',
      
    //    'success'
      
    //    )}
      
    //   else if(result.dismiss===Swal.DismissReason.cancel){
      
    //    Swal.fire(
      
    //    'Cancelled',
      
    //    'record not deleted:',
      
    //   'error'
      
    //    )
      
    //    }
      
    //    window.location.reload();
      
    //    })





    
    this.datasource.GetBookingsByShopId(this.id,this.booking.bookingStartTime).subscribe(data=>{
      this.bookingList=data;
    

    this.availableMachineId=[]
    
    this.machinesOccupiedId=[]


    for(let i=0;i<this.bookingList.length;i++){
      this.machinesOccupiedId.push(this.bookingList[i].machineId);
     }
    
     console.log(this.allMachinesId)
     this.availableMachineId=this.allMachinesId.filter(item =>this.machinesOccupiedId.indexOf(item) < 0);
     console.log(this.machinesOccupiedId)

    
    
    console.log(this.availableMachineId)
    console.log(Math.floor(Math.random() * 10));

    this.assignedMachine=this.availableMachineId[Math.floor(Math.random() * this.availableMachineId.length)]
    console.log(this.assignedMachine,"assigned")
    this.booking.machineId=this.assignedMachine

    
    
    
    
    this.datasource.GetReservationById(this.booking.reservationId).subscribe(data=>{
      this.booking.bill=data.charges;
      console.log(data.charges)

    })
    
    

    this.booking.pin=Math.floor(Math.random() * 999999)

    console.log(this.booking);
    
    if(this.allMachinesId.length>this.bookingList.length){
      if(form.valid){
        console.log(this.booking);
        this.datasource.GetMachineByMachineId(this.booking.machineId).subscribe(data=>{
          console.log(this.booking.machineId)
          this.machinedetails=data;
          console.log(this.machinedetails)
          this.machineName=this.machinedetails.machineName
          console.log(this.machineName);
          
          this.datasource.AddSlotBooking(this.booking,this.machineName).subscribe(Response=>{
            console.log("booking done");
            this.errorMessage="Slot Booked"
            console.log(this.booking)
    
            
          })
        })
        
      }
        
    }
    else{
      this.errorMessage="This slot is occupied"
    }
    
  })
  }
  hello(value:any){
   this.selectedvalue=value;
   console.log(this.selectedvalue) 
   console.log("juhwi")
   

  }

}
