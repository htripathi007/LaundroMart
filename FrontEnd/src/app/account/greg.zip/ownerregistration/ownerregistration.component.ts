import { group } from '@angular/animations';
import { JsonPipe } from '@angular/common';
import { Component, DoCheck, LOCALE_ID, OnInit } from '@angular/core';
import { NgForm, FormsModule, FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { LocationService } from 'src/app/location.service';
import { RegisterUser } from 'src/app/models/registeruser.model';
import { RestDataSource } from 'src/app/models/rest.datasource';
import { User } from 'src/app/models/user.model';
import { CustomvalidationService } from '../account/customvalidation.service';
// import {PasswordValidators } from './confirm-password-validator';
// import { Country, State, City }  from 'country-state-city';
// import { ICountry, IState, ICity } from 'country-state-city'
// import { LocationDropdownService } from 'src/app/location-dropdown.service';

@Component({
  selector: 'app-ownerregistration',
  templateUrl: './ownerregistration.component.html',
  styleUrls: ['./ownerregistration.component.css']
})

export class OwnerregistrationComponent implements OnInit, DoCheck {
  ownerReg: FormGroup;
  visible: boolean = true;
  changetype: boolean = true;
  public user = new User();
  public users: User[] = [];
  public passwordConf: boolean = false;
  public duplicateUserPhoneNumber: boolean = false;
  public states: any;
  public country: string = "IN";
  public state: any;
  public stateChosen: any;
  public stateCode: any;
  public cities: any;
  public cityChosen: any;
  public submitted: boolean = true;
  public registerForm?: FormGroup;
  public role='Owner';
  public registeruser= new RegisterUser;


  constructor(private datasource: RestDataSource, private router: Router, private service: LocationService, private fb: FormBuilder, private customValidator: CustomvalidationService) {
    //Rective form
    this.ownerReg = this.fb.group({
      firstName: new FormControl('', [Validators.required, Validators.pattern("^([A-Za-z]+[,.]?|[A-Za-z]+['-]?)+$")]),
      lastName: new FormControl('', [Validators.required, Validators.pattern("^([A-Za-z]+[,.]?|[A-Za-z]+['-]?)+$")]),
      email: new FormControl('', [Validators.required, Validators.email]),
      contact: new FormControl('', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      password: new FormControl('',
        [
          Validators.required,
          Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')
        ]),
      cpassword: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      pincode: new FormControl('', [Validators.required, Validators.pattern("((\\+91-?)|0)?[0-9]{6}$")]),
      stateChosen: new FormControl(''),
      cityChosen: new FormControl(''),
      // userRole:new FormControl(this.role)
    },
      {
        validators: this.Mustmatch("password", "cpassword")
      }
    )
    console.table(this.ownerReg.value);
    
  }

  get o() {
    return this.ownerReg.controls
  }
  onSubmit() {
    this.submitted = true;
    if (this.ownerReg.valid) {

      this.registeruser=this.ownerReg.value;
      console.log(this.registeruser);
      

      this.user.userRole = "Owner";
      this.user.userFirstName=this.registeruser.firstName;
      this.user.userLastName=this.registeruser.lastName;
      this.user.userEmail=this.registeruser.email;
      this.user.userPhoneNumber=this.registeruser.contact;
      this.user.userAddress=this.registeruser.address;
      this.user.userState=this.registeruser.stateChosen;
      this.user.userCity=this.registeruser.cityChosen;
      this.user.userPinCode=this.registeruser.pincode;
      

       console.log(this.user);
      

      this.datasource.registerUser(this.user)
        .subscribe(response => {
            this.router.navigateByUrl("/")
        });
      this.submitted = true;
    }
      alert('Form Submitted succesfully!!!\n Check the values in browser console.');
      console.table(this.ownerReg.value);
    }

  onFileSelected(event: any) {

    console.log(event);
  }

  ngOnInit() {

    this.datasource.GetUserForValidation()
      .subscribe(data => {
        this.users = data;
      })
    this.states = this.service.getStatesByCountry(this.country);    
  }
  ngDoCheck(){
        
    for(let i = 0; i < this.states.length; i++){
      if(this.states[i].name==this.stateChosen)
      {
        this.stateCode = this.states[i].isoCode;
      }
    }
   }


  onSelect(event: any) {
    console.log(event)
    let fileType = event.target.files[0].type;
    if (fileType.match(/image\/*/)) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.user.fileUri = event.target.result;
      }
    }
  }

  viewpass() {
    this.visible = !this.visible;
    this.changetype = !this.changetype;
  }

  // addUser(form: NgForm) {
  //   if (form.valid) {
  //     this.datasource.addUser(this.user)
  //       .subscribe(response => {
  //         this.router.navigateByUrl("/users");
  //       });
  //   }
  // }

  // handleConfirmPasswordChange(form: NgForm) {
  //   if (this.user.userPassword != this.user.userConfirmPassword) {
  //     this.passwordConf = true;
  //     return;
  //   }
  //   else {
  //     this.passwordConf = false;
  //   }
  // }

  sendCode() {
    
    this.cities = this.service.getCitiesByState('IN', this.stateCode);
    this.user.userState = this.stateChosen;
  }

  changeCity() {
    this.user.userCity = this.cityChosen;
  }
  // userPhoneNumberCheck(form: NgForm) {
  //     var empList = this.users.map(x => x.userPhoneNumber)
  //     for (let i = 0; i < empList.length; i++) {
  //       if (empList[i] != this.user.userPhoneNumber) {
  //         this.duplicateUserPhoneNumber = false;
  //       }
  //       else {
  //         this.duplicateUserPhoneNumber = true;
  //         return;
  //       }
  //     }
  // }

  // registerUser(form: NgForm) {
  //   console.log(form.value);
  //   console.log("form entery");
  //   this.submitted = false;

  //   if (this.user.userPassword != this.user.userConfirmPassword) {
  //     this.passwordConf = true;
  //     return;
  //   }
  //   else {
  //     this.passwordConf = false;
  //   }
  //   if (form.valid) {

  //     this.user.userRole = "Owner";
  //     console.log(this.user);

  //     this.datasource.registerUser(this.user)
  //       .subscribe(response => {
  //         if (response.id != undefined) {
  //           this.duplicateUserPhoneNumber = false;
  //           this.router.navigateByUrl("/")
  //         }
  //         else {
  //           this.duplicateUserPhoneNumber = true;
  //         }
  //       })
  //     this.submitted = true;
  //   }
  // }



  Mustmatch(password: any, compassword: any) 
  {
    return (formGroup: FormGroup) => 
    {
      const passwordcontrol = formGroup.controls[password]; 
      const compasswordcontrol = formGroup.controls[compassword];    //  console.log(passwordcontrol,"passwordcontrol",compasswordcontrol,"compasswordcontrol")      
      if (compasswordcontrol.errors && !compasswordcontrol.errors['Mustmatch']) { 
         return;
      } 
      if (passwordcontrol.value !== compasswordcontrol.value) 
      {
        compasswordcontrol.setErrors({ Mustmatch: true });
      }
      else {
        compasswordcontrol.setErrors(null);
      }
    };
   }
  }


  