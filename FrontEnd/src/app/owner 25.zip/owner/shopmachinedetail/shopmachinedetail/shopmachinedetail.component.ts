import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MachineDetail } from 'src/app/models/machinedetail';
import { RestDataSource } from 'src/app/models/rest.datasource';
import { ShopDetail } from 'src/app/models/shopdetail';
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-shopmachinedetail',
  templateUrl: './shopmachinedetail.component.html',
  styleUrls: ['./shopmachinedetail.component.css']
})
export class ShopmachinedetailComponent {

  formModal: any;
  public machines: MachineDetail[] = [];
  public machine= new MachineDetail;
  public shop = new ShopDetail();
  public id:any;
  public machineelement = new MachineDetail
  public user = new User()
  public userPhoneNo: string | null = sessionStorage.getItem("userPhoneNumber");

  // pagination
  title = 'pagination';
  page: number = 1;
  count: number = 0;
  tableSize: number = 5;
  tableSizes: any = [5, 10, 15, 20];

  //filter
  searchText: any;

  constructor(private datasource: RestDataSource, private router: Router,private route :ActivatedRoute) {

    }
    ngOnInit(){

      this.id = this.route.snapshot.paramMap.get('id');
      this.id=parseInt(this.id);
  
        this.datasource.GetMachinesByShopId(this.id).subscribe(data => {
          this.machines = data;
          console.log(this.machines);
          console.log(this.id)
          });
    }

    changeWorkingStatus(workingStatus:any){
      console.log(workingStatus);
      
      this.machineelement.workingStatus=!workingStatus;
      console.log(this.machineelement.workingStatus);
        
    }
    changeLockingStatus(lockStatus:any){
      this.machineelement.lockStatus=!lockStatus; 
    }

  machineList():void{
    this.datasource.GetMachinesByShopId(this.shop.shopId).subscribe(data => {
      this.machines = data;
      console.log(this.shop.shopId);

  });
}

    updateid( machine : any){
      this.machineelement = machine;
      console.log(this.machineelement.workingStatus);
    }

    deleteid(machine:any){

      this.machineelement=machine;
      console.log(this.machineelement.shopId)
  
    }

    addMachine(form: NgForm) {
      if (form.valid) {

        this.machineelement.shopId=this.shop.shopId;
        this.machineelement.userId=this.shop.userId;

        // if(this.machineelement.workingStatus === "true"){
        //   this.machineelement.workingStatus=true;
        // }
        // else{
        //   this.machineelement.workingStatus=false;
        // };
  
        // if(this.machineelement.lockStatus === "true"){
        //   this.machineelement.lockStatus=true;
        // }
        // else{
        //   this.machineelement.lockStatus=false;
        // };

        this.datasource.AddMachine(this.machineelement).subscribe(reponse => {
          console.log(this.machineelement);
          window.location.reload();  
        });
      }
    }

    updatemachineid(id: any) {

      // if(this.machineelement.workingStatus === "true"){
      //   this.machineelement.workingStatus=true;
      // }
      // else if (this.machineelement.workingStatus === "false"){
      //   this.machineelement.workingStatus=false;
      // };

      // if(this.machineelement.lockStatus === "true"){
      //   this.machineelement.lockStatus=true;
      // }
      // else if (this.machineelement.lockStatus === "false"){
      //   this.machineelement.lockStatus=false;
      // };

      this.datasource.UpdateMachine(this.machineelement.machineId, this.machineelement).subscribe(reponse => {
          window.location.reload();
      });
    }


    patchmachineid(id: any) {
      this.datasource.UpdateMachine(this.machineelement.machineId, this.machineelement).subscribe(reponse => {
        console.log(this.machineelement.workingStatus);
        });
    }
    deletemachineid(id: any) {
      this.datasource.DeleteMachine(this.machineelement.machineId).subscribe(reponse => {
        window.location.reload();
  
      });
    }

    openModal(){
      this.formModal.show();
    }
  
    closeModal() {
      this.formModal.hide();
    }
  
    // pagination code
    onTableDataChange(event: any) {
      this.page = event;
      console.log(this.page);
      this.machineList();
    }
  
    logout() {
      sessionStorage.removeItem("token");
      sessionStorage.removeItem("role");
      sessionStorage.removeItem("username");
      this.router.navigateByUrl("/");
    }


}
