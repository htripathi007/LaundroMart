import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { SidebarModule } from 'ng-sidebar';
import { OwnerprofileComponent } from './OwnerProfile/ownerprofile/ownerprofile.component';
import { MyshopComponent } from './myshop/myshop/myshop.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { OwnermachinedetailComponent } from './ownermachinedetail/ownermachinedetail/ownermachinedetail.component';
import { ShopmachinedetailComponent } from './shopmachinedetail/shopmachinedetail/shopmachinedetail.component';



@NgModule({
  declarations: [SidebarComponent,OwnerprofileComponent, MyshopComponent, OwnermachinedetailComponent, ShopmachinedetailComponent],
  imports: [
    CommonModule,AppRoutingModule,SidebarModule.forRoot(),NgxPaginationModule,FormsModule
  ]
})
export class OwnerModule { }
