import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestDataSource } from 'src/app/models/rest.datasource';
import { User } from 'src/app/models/user.model';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'ownerprofile',
  templateUrl: './ownerprofile.component.html',
  styleUrls: ['./ownerprofile.component.css']
})
export class OwnerprofileComponent implements OnInit  {

  public user = new User()
  public userPhoneNo : string | null = sessionStorage.getItem("userPhoneNumber");
  public fieldTextType?: boolean;
  public imagePath?:any;

  constructor(private datasource:RestDataSource, private router:Router,private domSanitizer: DomSanitizer) {
    
    
  }
    ngOnInit():void{
      this.datasource.GetUserInfo(this.userPhoneNo).subscribe(data=>{
        this.user = data;
          // this.imagePath = this.domSanitizer.bypassSecurityTrustUrl(this.user.actualFileUrl!);
          console.log(this.imagePath);
        }
      )

    }
  
  updateuser(id: any) {

    this.datasource.UpdateUser(this.user.userId, this.user).subscribe(reponse => {
      console.log(this.user.userPhoneNumber);
      window.location.reload();

    });
  }
  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }


  logout() {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("role");
    sessionStorage.removeItem("userphoneno");
    this.router.navigateByUrl("/");
    }


}
